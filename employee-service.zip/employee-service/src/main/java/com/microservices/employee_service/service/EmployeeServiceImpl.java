package com.microservices.employee_service.service;

import com.microservices.employee_service.dto.APIResponseDTO;
import com.microservices.employee_service.dto.DepartmentDTO;
import com.microservices.employee_service.dto.EmployeeDTO;
import com.microservices.employee_service.dto.OrganizationDTO;
import com.microservices.employee_service.entity.Employee;
import com.microservices.employee_service.repository.EmployeeRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeServiceImpl.class);
    private EmployeeRepository employeeRepository;
    private ModelMapper modelMapper;
    //private RestTemplate restTemplate;
    private WebClient webClient;
    private FeignAPIClient fiegnAPIClient;

    @Override
    public EmployeeDTO saveEmployee(EmployeeDTO employeeDTO) {
        Employee employee = modelMapper.map(employeeDTO, Employee.class);
        Employee savedEmployee = employeeRepository.save(employee);

        EmployeeDTO savedEmployeeDto = modelMapper.map(savedEmployee, EmployeeDTO.class);
        return savedEmployeeDto;
    }

    @Override
    //@CircuitBreaker(name = "${spring.application.name}", fallbackMethod = "getDefaultDepartment")
    @Retry(name = "${spring.application.name}", fallbackMethod = "getDefaultDepartment")
    public APIResponseDTO getEmployeeById(long employeeId) {
        LOGGER.info("inside getEmployeeById()");
        Employee employee = employeeRepository.findById(employeeId).get();
        //Using Rest Template for communication between microservices
/*        ResponseEntity<DepartmentDTO> responseEntity = restTemplate
                .getForEntity("http://localhost:8080/api/department/" + employee.getDepartmentCode(),
                        DepartmentDTO.class);
        DepartmentDTO departmentDTO = responseEntity.getBody();*/

        //Using WebClient for communication between microservices
        /*DepartmentDTO departmentDTO = webClient.get()
                .uri("http://localhost:8080/api/department/" + employee.getDepartmentCode())
                .retrieve()
                .bodyToMono(DepartmentDTO.class)
                .block();*/
        DepartmentDTO departmentDTO = fiegnAPIClient.getDepartmentByCode(employee.getDepartmentCode());
        //OrganizationDTO organizationDTO = fiegnAPIClient.getOrganizationByCode(employee.getOrganizationCode());

        //**********************************************************************************************//
            //The reason we are using webClient is that Feign Client needs
            // to be configured with different interfaces for different microservices
        //**********************************************************************************************//

        //Trying Organization DTO with webClient
        OrganizationDTO orgDTO = webClient.get()
                .uri("http://localhost:8083/api/organizations/" + employee.getOrganizationCode())
                .retrieve()
                .bodyToMono(OrganizationDTO.class)
                .block();

        EmployeeDTO employeeDTO = modelMapper.map(employee, EmployeeDTO.class);

        APIResponseDTO apiResponseDTO = new APIResponseDTO();
        apiResponseDTO.setEmployeeDTO(employeeDTO);
        apiResponseDTO.setDepartmentDTO(departmentDTO);
        apiResponseDTO.setOrganizationDTO(orgDTO);
        return apiResponseDTO;
    }

    public APIResponseDTO getDefaultDepartment(long employeeId, Throwable throwable) {
        {
            LOGGER.info("inside getDefaultDepartment()");
            Employee employee = employeeRepository.findById(employeeId).get();

            // What we are doing here is: instead of calling the department
            // service(assume it is down), we are creating a default
            // message that will return to the service call during runtime incase
            // the called service is down
            DepartmentDTO departmentDTO = new DepartmentDTO();

            departmentDTO.setDepartmentName("Default R&D department");
            departmentDTO.setDepartmentCode("RD001");
            departmentDTO.setDepartmentDescription("This is a research and development department");

            EmployeeDTO employeeDTO = modelMapper.map(employee, EmployeeDTO.class);
            APIResponseDTO apiResponseDTO = new APIResponseDTO();
            apiResponseDTO.setEmployeeDTO(employeeDTO);
            apiResponseDTO.setDepartmentDTO(departmentDTO);
            return apiResponseDTO;
        }
    }
}
