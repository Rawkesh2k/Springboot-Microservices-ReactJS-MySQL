package com.microservices.employee_service.controller;

import com.microservices.employee_service.dto.APIResponseDTO;
import com.microservices.employee_service.dto.EmployeeDTO;
import com.microservices.employee_service.service.EmployeeService;
import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/employees")
@AllArgsConstructor
@Tag(name = "Employee microservice - Employee Controller",
        description = "Employee Controller exposes Rest APIs for the Employee service",
        externalDocs = @ExternalDocumentation(description = "This is the external documentation site to navigate",
                url = "www.externalsitedocs.com"))
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    //Build saveEmployee Rest API

    @PostMapping
    @Tag(name = "SAVE Employee Rest API",
    description = "SAVE employee Rest API saves the employee record to the database")
    @ApiResponse(responseCode = "201",
    description = "HTTP STATUS: 201 - CREATED")
    public ResponseEntity<EmployeeDTO> saveEmployee(@RequestBody EmployeeDTO employeeDTO) {
        EmployeeDTO savedEmployee = employeeService.saveEmployee(employeeDTO);
        return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
    }

    //Build getEmployee Rest APi
    @Tag(name = "GET Employee Rest API",
            description = "GET employee Rest API fetches the employee record from the database")
    @ApiResponse(responseCode = "200",
            description = "HTTP STATUS: 200 - SUCCESS")
    @GetMapping("/{employeeId}")
    public ResponseEntity<APIResponseDTO> getEmployee(@PathVariable long employeeId) {
        APIResponseDTO employeeById = employeeService.getEmployeeById(employeeId);
        return new ResponseEntity<>(employeeById, HttpStatus.OK);
    }
}
