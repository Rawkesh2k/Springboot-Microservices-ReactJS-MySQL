package com.microservices.employee_service.service;

import com.microservices.employee_service.dto.DepartmentDTO;
import com.microservices.employee_service.dto.OrganizationDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "DEPARTMENT-SERVICE")
public interface FeignAPIClient {
    //Get Department Rest API by Dept Code

    @GetMapping("/api/department/{department-code}")
    DepartmentDTO getDepartmentByCode(@PathVariable("department-code") String departmentCode);

    @GetMapping("/api/organizations/{organizationCode}")
    OrganizationDTO getOrganizationByCode(@PathVariable("organizationCode") String organizationCode);
}


