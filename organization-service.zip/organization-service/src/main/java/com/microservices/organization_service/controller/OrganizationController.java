package com.microservices.organization_service.controller;

import com.microservices.organization_service.dto.OrganizationDTO;
import com.microservices.organization_service.service.OrganizationService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/organizations")
@AllArgsConstructor
@Tag(name = "Organization MicroService - Controller",
        description = "Organization MicroService - Controller exposes Rest APIs for Organization MicroService")
public class OrganizationController {
    private OrganizationService organizationService;

    //Build saveOrganization Rest API

    @Operation(summary = "SAVE organization Rest API",
            description = "SAVE organization Rest API is used to SAVE the organization record into database")
    @ApiResponse(responseCode = "201",description = "HTTP Status 201 CREATED")
    @PostMapping
    public ResponseEntity<OrganizationDTO> saveOrganization(@RequestBody OrganizationDTO organizationDTO) {
        OrganizationDTO savedOrganizationDto = organizationService.saveOrganization(organizationDTO);
        return new ResponseEntity<>(savedOrganizationDto, HttpStatus.CREATED);
    }

    //Build getOrganizationByCode Rest API

    @Operation(summary = "GET organization Rest API",
            description = "GET organization Rest API is used to GET the organization record from the database")
    @ApiResponse(responseCode = "200",description = "HTTP Status 200 SUCCESS")
    @GetMapping("/{organizationCode}")
    public ResponseEntity<OrganizationDTO> getOrganizationByCode(@PathVariable String organizationCode) {
        OrganizationDTO organizationByCode = organizationService.getOrganizationByCode(organizationCode);
        return new ResponseEntity<>(organizationByCode, HttpStatus.OK);
    }

    //Build saveAllOrganizations Rest API

    @PostMapping("/saveAllOrganizations")
    public ResponseEntity<List<OrganizationDTO>> saveAllOrganizations(@RequestBody List<OrganizationDTO> organizationDTOList) {
        List<OrganizationDTO> savedOrganizationDTOList = organizationService.saveAllOrganization(organizationDTOList);
        return new ResponseEntity<>(savedOrganizationDTOList, HttpStatus.CREATED);
    }
}
