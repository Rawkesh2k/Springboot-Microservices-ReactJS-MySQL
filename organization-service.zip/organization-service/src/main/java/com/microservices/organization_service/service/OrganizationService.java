package com.microservices.organization_service.service;

import com.microservices.organization_service.dto.OrganizationDTO;

import java.util.List;

public interface OrganizationService {
    OrganizationDTO saveOrganization(OrganizationDTO organizationDTO);

    OrganizationDTO getOrganizationByCode(String organizationCode);

    List<OrganizationDTO> saveAllOrganization(List<OrganizationDTO> organizationDTOList);
}
