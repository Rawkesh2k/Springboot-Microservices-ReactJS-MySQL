package com.microservices.organization_service.service;

import com.microservices.organization_service.dto.OrganizationDTO;
import com.microservices.organization_service.entity.Organization;
import com.microservices.organization_service.mapper.OrganizationMapper;
import com.microservices.organization_service.repository.OrganizationRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class OrganizationServiceImpl implements OrganizationService {
    private OrganizationRepository organizationRepository;

    @Override
    public OrganizationDTO saveOrganization(OrganizationDTO organizationDTO) {
        //Convert orgDto to Org Entity
        Organization organization = OrganizationMapper.mapToOrganization(organizationDTO);

        Organization savedOrganization = organizationRepository.save(organization);
        //Convert org to OrgDto Entity in order to placate the return type
        return OrganizationMapper.mapToOrganizationDTO(savedOrganization);
    }

    @Override
    public OrganizationDTO getOrganizationByCode(String organizationCode) {
        Organization byOrganizationCode = organizationRepository.findByOrganizationCode(organizationCode);
        return OrganizationMapper.mapToOrganizationDTO(byOrganizationCode);
    }

    @Override
    public List<OrganizationDTO> saveAllOrganization(List<OrganizationDTO> organizationDTOList) {
        // Convert the list of OrganizationDTOs to a list of Organization entities
        List<Organization> organizationsList = organizationDTOList.stream()
                .map(OrganizationMapper::mapToOrganization)
                .collect(Collectors.toList());
        // Save all organizations using saveAll method
        List<Organization> savedOrganizationList = organizationRepository.saveAll(organizationsList);
        // Convert the saved organizations back to OrganizationDTOs and return them
        return savedOrganizationList.stream()
                .map(OrganizationMapper::mapToOrganizationDTO)
                .collect(Collectors.toList());
    }

}
