package com.microservices.organization_service;

import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
@OpenAPIDefinition(info = @Info(summary = "ORGANIZATION MICROSERVICE- ORGANIZATION REST APIS",
        description = "ORGANIZATION MICROSERVICE- ORGANIZATION REST APIS documentation",
        version = "v1.0",
        contact = @Contact(name = "Rakesh", email = "Rakesh@gmail.com", url = "www.samplewebsite.com"),
        license = @License(name = "Apache 2.0", url = "www.apache.com")),
        externalDocs = @ExternalDocumentation(url = "www.externaldocs.com/extrenaldocs",
                                            description = "External Documentation for Organization service"))
public class OrganizationServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrganizationServiceApplication.class, args);
    }

}
